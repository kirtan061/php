<?php
$folder = "images/";  // Folder containing images
$allowed_extensions = ['jpg','jpeg','png','gif','webp'];

// Scan folder
$files = scandir($folder);

echo "<h2>Simple Image Gallery</h2>";
echo "<div style='display:flex; flex-wrap:wrap; gap:15px;'>";

foreach ($files as $file) {

    $filepath = $folder . $file;
    $ext = strtolower(pathinfo($filepath, PATHINFO_EXTENSION));

    // Only show allowed image files
    if (in_array($ext, $allowed_extensions)) {
        echo "<img src='$filepath' 
               style='width:200px; height:150px; object-fit:cover; border:2px solid #ddd; border-radius:8px;' />";
    }
}

echo "</div>";
?>
